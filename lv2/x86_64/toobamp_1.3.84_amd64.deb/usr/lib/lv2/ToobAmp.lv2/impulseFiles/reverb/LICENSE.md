Factory Convolution Reverb files are provided under the following licenses. 

### Arthur Sykes Rymer Auditorium.wav

By: [www.openairlib.net](https://www.openairlib.net/), University of York

This work is provided under a Creative Commons Attribution 4.0 International License.
<https://creativecommons.org/licenses/by/4.0/>

Source: <https://www.openair.hosted.york.ac.uk/?page_id=425> 

---

### EMT 140 Medium 2.wav

EMT 140 large analog plate reverb.

By: Greg Hopkins, Hopkins Media Services

This work is provided under a Creative Commons Attribution 4.0 International License.
<https://creativecommons.org/licenses/by/4.0/>

Source: <https://hopkinsmedia.services/ir>

---


### Jack Lyons Hall, University of York.wav

By: [www.openairlib.net](https://www.openairlib.net/), Audiolab University of York, Alex Duffell, Aishwarya Sridhar, Zhong Li

This work is provided under a Creative Commons Attribution 4.0 International License.
<https://creativecommons.org/licenses/by/4.0/> 

Source: <https://www.openair.hosted.york.ac.uk/?page_id=571> 

---

### Koli National Park - Winter.wav

By: [www.openairlib.net](https://www.openairlib.net/), Audio Lab University of York, Andrew Chadwick, Simon Shelley

This work is provided under a Creative Commons Attribution 4.0 International License.
<https://creativecommons.org/licenses/by/4.0/> 

Source: <https://www.openair.hosted.york.ac.uk/?page_id=584> 

---

### St. Margaret’s Church.wav

By: [www.openairlib.net](https://www.openairlib.net/), AudioLab University of York, www.ncem.co.uk

This work is provided under a Creative Commons Attribution 4.0 International License.
<https://creativecommons.org/licenses/by/4.0/> 

Source: <https://www.openair.hosted.york.ac.uk/?page_id=702>

---

### Genesis 6 Studio Live Room.wav

By: [www.openairlib.net](https://www.openairlib.net/)

This work is provided under a Creative Commons Attribution 4.0 International License.
<https://creativecommons.org/licenses/by/4.0/>

Source: <https://www.openair.hosted.york.ac.uk/?page_id=483>
